// ProjectTwo.cpp

// Karina Jacuinde
// CS 300 Final Project
// All code needed in this file
// Data load name is "cs300-data-input.csv"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>

// **********
// Data Types
// **********
struct Course {
    std::string courseNumber;                  
    std::string courseTitle;                   
    std::vector<std::string> prerequisites;    
};

// **********
// Helper functions to be used for string formatting
// Added these to help with input validation per feedback recommendations
// Function trim will remove whitespace characters
// Function toUpperCopy will convert user input on course numbers with appropriate capitalization
// **********

// went on stackoverflow.com for help with trim
static void trim(std::string& s) {
    auto notspace = [](int ch) { return !std::isspace(static_cast<unsigned char>(ch)); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notspace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notspace).base(), s.end());
}

static std::string toUpperCopy(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return s;
}

// **********
// Defining our tree class
// Binary Search Tree (courseTree from pseudo)
// Referenced Module 5 Assignment for class definition and made adjustments to match my pseudocode
// **********
class BinarySearchTree {
public:
    BinarySearchTree() : root(nullptr) {}
    ~BinarySearchTree() { destroy(root); }

    void Insert(const Course& course) {
        if (!root) { root = new Node(course); return; }
        Node* cur = root;
        while (true) {
            if (course.courseNumber < cur->course.courseNumber) {
                if (cur->left) cur = cur->left;
                else { cur->left = new Node(course); break; }
            }
            else {
                if (cur->right) cur = cur->right;
                else { cur->right = new Node(course); break; }
            }
        }
    }

    // This will be used to find course by course number
    // Will be called in SearchAndPrintFromTree()
    const Course* Search(const std::string& number) const {
        Node* cur = root;
        while (cur) {
            if (number == cur->course.courseNumber) return &cur->course;
            cur = (number < cur->course.courseNumber) ? cur->left : cur->right;
        }
        return nullptr;
    }

    // TraverseTreeInOrder() will be called in PrintSortedTree()
    void TraverseTreeInOrder() const { inOrder(root); }

private:
    struct Node {
        Course course;
        Node* left;
        Node* right;
        explicit Node(const Course& c) : course(c), left(nullptr), right(nullptr) {}
    };
    Node* root;

    static void destroy(Node* n) {
        if (!n) return;
        destroy(n->left);
        destroy(n->right);
        delete n;
    }

    // Referenced Module 5 for inOrder with adjustments
    // Did not need preOrder or postOrder as we're only doing alphanumeric order
    static void inOrder(Node* n) {
        if (!n) return;
        inOrder(n->left);
        std::cout << n->course.courseNumber << ": " << n->course.courseTitle << "\n";
        if (!n->course.prerequisites.empty()) {
            std::cout << "  prerequisites: ";
            for (size_t i = 0; i < n->course.prerequisites.size(); ++i) {
                std::cout << n->course.prerequisites[i];
                if (i + 1 < n->course.prerequisites.size()) std::cout << ", ";
            }
            std::cout << "\n";
        }
        inOrder(n->right);
    }
};

// **********
// Global Data Structures
// Using these to keep program in one file
// courseTree used to store courses in tree
// courseByNumber used to look up courses by their number
// **********
static BinarySearchTree courseTree;
static std::unordered_map<std::string, Course> courseByNumber;

// **********
// OpenAndValidate(fileName)
// First pseudocode from Milestone
// Matches pseudocode with the improvement of using a helper function for string formatting
// **********
bool OpenAndValidate(const std::string& fileName,
    std::vector<std::vector<std::string>>& courseInformation,
    std::vector<std::string>& courseNumbers)
{
    courseInformation.clear();
    courseNumbers.clear();

    // Ensuring we can open file
    std::ifstream fin(fileName);
    if (!fin.is_open()) {
        std::cout << "Error, file could not be opened\n";
        return false;
    }

    // Formatting each line and adding to list
    std::string line;
    while (std::getline(fin, line)) {
        trim(line);
        if (line.empty()) continue;

        std::vector<std::string> courseItems;
        std::stringstream ss(line);
        std::string item;
        while (std::getline(ss, item, ',')) {
            trim(item);
            if (!item.empty()) courseItems.push_back(item);
        }

        if (courseItems.size() < 2) {
            std::cout << "Error, line needs a course number and course name\n";
            fin.close();
            return false;
        }

        // Using toUpperCopy to convert to searchable format while keeping original search
        courseNumbers.push_back(toUpperCopy(courseItems[0]));
        courseItems[0] = toUpperCopy(courseItems[0]);
        for (size_t i = 2; i < courseItems.size(); ++i) {
            courseItems[i] = toUpperCopy(courseItems[i]);
        }

        courseInformation.push_back(std::move(courseItems));
    }
    fin.close();

    // Ensuring that all prerequisites are listed as a course
    for (const auto& course : courseInformation) {
        if (course.size() > 2) {
            for (size_t i = 2; i < course.size(); ++i) {
                const std::string& prereq = course[i];
                if (std::find(courseNumbers.begin(), courseNumbers.end(), prereq) == courseNumbers.end()) {
                    std::cout << "Error, prerequisite not listed as course: " << prereq << "\n";
                    return false;
                }
            }
        }
    }
    return true;
}

// **********
// LoadCourseObjectsToTree(fileName)
//   Second pseudocode from Milestones
// ***********
bool LoadCourseObjectsToTree(const std::string& fileName) {
    std::vector<std::vector<std::string>> courseInformation;
    std::vector<std::string> courseNumbers;

    // Ensuring OpenAndValidate works first
    if (!OpenAndValidate(fileName, courseInformation, courseNumbers)) {
        return false;
    }

    courseTree = BinarySearchTree();

    // Starting with empty
    courseByNumber.clear();

    for (const auto& items : courseInformation) {
        Course c;
        // variable c represents one course from courseInformation
        c.courseNumber = items[0];                  
        if (items.size() >= 2) {
            c.courseTitle = items[1];  
        }
        else {
            c.courseTitle = "";  
        }
        for (size_t i = 2; i < items.size(); ++i) {
            c.prerequisites.push_back(items[i]);    
        }
        courseTree.Insert(c);
        courseByNumber[c.courseNumber] = c;
    }
    return true;
}

// **********
// PrintSortedTree(courseTree)
// **********
void PrintSortedTree() {
    courseTree.TraverseTreeInOrder();
}

// **********
// SearchAndPrintFromTree(courseTree, searchNum)
// **********
void SearchAndPrintFromTree(const std::string& searchNum) {
    const Course* nodeCourse = courseTree.Search(searchNum);
    if (nodeCourse) {
        std::cout << nodeCourse->courseNumber << "\n";
        std::cout << nodeCourse->courseTitle << "\n";

        if (!nodeCourse->prerequisites.empty()) {
            std::cout << "Prerequisites:\n";
            for (const auto& p : nodeCourse->prerequisites) {
                auto it = courseByNumber.find(p);
                if (it != courseByNumber.end()) {
                    std::cout << "  " << p << " - " << it->second.courseTitle << "\n";
                }
                else {
                    std::cout << "  " << p << "\n";
                }
            }
        }
        else {
            std::cout << "Prerequisites: None\n";
        }
        return;
    }
    std::cout << "Course Not Found\n";
}

// **********
// Main menu
// This menu code was adapted from the starter code from Module 5 assignment
// Menu code was simplified from Module 5 assignment to meet this project's requirements
// Also differs from my pseudo menu as we are not checking for type of data structure
// Added more detailed input validation than my pseudocode originally had per feedback recommendations
// I renamed the data to: "cs300-data-input.csv"
// **********
int main() {
    bool dataLoaded = false;
    std::string choice;

    while (true) {
        std::cout << "\nMenu:\n"
            << "  1. Load Data Structure\n"
            << "  2. Print Course List (alphanumeric)\n"
            << "  3. Print Course Information\n"
            << "  9. Exit\n"
            << "Enter option: ";

        if (!std::getline(std::cin, choice)) break;

        if (choice == "1") {
            std::cout << "Enter file name including .csv extension: ";
            std::string fileName;
            std::getline(std::cin, fileName);

            if (fileName.empty()) {
                std::cout << "Error: file name cannot be empty\n";
                continue;
            }

            if (LoadCourseObjectsToTree(fileName)) {
                dataLoaded = true;
                std::cout << "Data loaded successfully\n";
            }
            else {
                dataLoaded = false;
                std::cout << "Error: data not loaded.\n";
            }

        }
        else if (choice == "2") {
            if (!dataLoaded) {
                std::cout << "Please load data (option 1)\n";
                continue;
            }
            PrintSortedTree();

        }
        else if (choice == "3") {
            if (!dataLoaded) {
                std::cout << "Please load data (option 1)\n";
                continue;
            }
            std::cout << "Enter course number including prefix: ";
            std::string searchNum;
            std::getline(std::cin, searchNum);
            if (searchNum.empty()) {
                std::cout << "Error: course number cannot be empty\n";
                continue;
            }
            SearchAndPrintFromTree(toUpperCopy(searchNum));

        }
        else if (choice == "9") {
            std::cout << "Exiting\n";
            break;

        }
        else {
            std::cout << "Invalid input. Please choose 1, 2, 3, or 9\n";
        }
    }
    return 0;
}

