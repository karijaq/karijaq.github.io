Course Catalog Program in Python

This project is a Python version of my original C++ course catalog program that was created as part of CS300 at SNHU. It loads course data from a CSV file or SQLite database, stores it in a dictionary, and allows the user to :
    > Load the data
    > Print all courses alphabetically
    > Look up a course and view its direct and indirect prerequisites

 Project Structure
    To keep this version organized and easy to modify, the code is split into 3 Python files:
        > main.py runs the program, shows the user menu, handles database lookups, and prints course information
        > models.py holds the Course class and the recursive get_all_prereqs() function
        > data.py loads course data from course.db or, if database is empty, reads from CSV and saves everything into
        the database and dictionary

How to run program:
    > Open the folder in VS Code
    > Make sure data_input.csv is in same folder as Python files (only needed the first time)
    > In VS terminal, run:
        python3 main.py
