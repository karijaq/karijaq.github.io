# Main file displays the user menu and runs overall program

import sqlite3
from data import load_data
from models import Course, get_all_prereqs

# Display Menu Function
def display_menu():
    print(" Menu:")
    print(" 1. Load Data before continuing")
    print(" 2. Print Course List Alphabetically")
    print(" 3. Print Course information")
    print(" 9. Exit")
    return input ("Enter option: ").strip()

# DB helper function
def get_course_from_db(course_code):
    """Return a Course object for given code, or None if not found."""
    connection = sqlite3.connect("course.db")
    db_helper = connection.cursor()

    db_helper.execute(
        "SELECT number, title, prereqs FROM course_catalog WHERE number = ?",
        (course_code,)
    )
    row = db_helper.fetchone()
    connection.close

    if row is None:
        return None
    
    number, title, prereq_text = row

    if prereq_text:
        prereqs = [p.strip().upper() for p in prereq_text.split(",")]

    else: 
        prereqs = []

    return Course(number, title, prereqs) 
       

def main():
    data_loaded = False
    #tree = None
    courses_by_number = {}
    while True:
        choice = display_menu()

        if choice == "1":
            print("Loading data....")
            try:
                courses_by_number = load_data("data_input.csv")
                data_loaded = True
                print("Data loaded successfully")
            except FileNotFoundError:
                print("ERROR: Could not find data_input.csv")
                data_loaded = False    

        elif choice == "2":
            if not data_loaded:
                print("Please load data before continuing (Option 1)")
                continue
            print("\nCourse List:")
            for number in sorted(courses_by_number.keys()):
                course = courses_by_number[number]
                print(f"{course.number}: {course.title}")


        elif choice == "3":
            if not data_loaded:
                print("Please load data before continuing (Option 1)")
                continue
            search = input("Enter course number including prefix: ").strip().upper()

            if not search:
                print("ERROR: course by number cannot be empty")
                continue
            
            course = get_course_from_db(search)

            if course is None:
                print("Course not found")
                continue
            print(f"\n{course.number}")
            print(course.title)

            all_course_codes = get_all_prereqs(course.number, courses_by_number)
            
            # display set of prerequisites, direct and indirect
            if all_course_codes:
                print("Prerequisites:")

                direct_prereqs = set(course.prerequisites)

                for course_code in course.prerequisites:
                    prereq_course = courses_by_number.get(course_code)
                    if prereq_course:
                        print(f"{course_code} - {prereq_course.title}")
                    else:
                        print(f"{course_code}")

                indirect_prereqs = [code for code in all_course_codes if code not in direct_prereqs]

                if indirect_prereqs:
                    print("\nIndirect prerequisites:")
                    for course_code in indirect_prereqs:
                        prereq_course = courses_by_number.get(course_code)
                        if prereq_course:
                            print(f"{course_code} - {prereq_course.title}")
                        else:
                            print(f"{course_code}")

            else:
                print("Prerequisites: None")            
                

        elif choice == "9":
            print ("Exiting program. Goodbye!")  
            break
        else: 
            print("Invalid input. Choose 1, 2, 3, or 9")

if __name__=="__main__":
    main()              

