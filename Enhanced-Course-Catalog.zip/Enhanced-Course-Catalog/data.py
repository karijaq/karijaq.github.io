# Data file that loads course information from the CSV into our tree and dictionary

import csv
import sqlite3
from models import Course#, BinarySearchTree

# Connect to database
connection = sqlite3.connect("course.db")
db_helper = connection.cursor()

db_helper.execute("DROP TABLE IF EXISTS course_catalog")
db_helper.execute("""
CREATE TABLE IF NOT EXISTS  course_catalog(
    number TEXT PRIMARY KEY,
    title TEXT,
    prereqs TEXT
    )
                  """)
connection.commit()


def load_data(file_name):
    """Load courses from database, CSV availabe as backup"""
    
    #tree = BinarySearchTree()
    courses_by_number = {}

    # Try to read from DB
    db_helper.execute("SELECT number, title, prereqs FROM course_catalog")
    rows = db_helper.fetchall()

    # If table has data
    if rows:
        for number, title, prereq_text in rows:
            if prereq_text:
                prereqs = [p.strip().upper() for p in prereq_text.split(",")]
            else:
                prereqs = []

            course = Course(number, title, prereqs)
            courses_by_number[number] = course

        return courses_by_number            

    # If DB empty, use CSV and fill DB
    with open(file_name, newline='') as csvfile:
        reader = csv.reader(csvfile)

        for row in reader:
            if not row:
                continue

            number = row[0].strip().upper()
            title = row[1].strip()
            prereqs = [p.strip().upper() for p in row[2:]]

            course = Course(number, title, prereqs)

            #tree.insert(course)
            courses_by_number[number] = course

            db_helper.execute(
                "INSERT OR REPLACE INTO course_catalog (number, title, prereqs) VALUES (?, ?, ?)",
                (number, title, ",".join(prereqs))
            )

    connection.commit()        

    return courses_by_number
