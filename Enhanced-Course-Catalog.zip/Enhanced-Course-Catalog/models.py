# This file defines the Course object and the Binary Search Tree structure used in the program

class Course:
    def __init__(self, number, title, prerequisites=None):
        self.number = number
        self.title = title
        self.prerequisites = prerequisites or []   

# Listing all prerequisits of a course, direct and indirect
def get_all_prereqs(code, courses_by_number, checked_courses=None):
    """Return a list of all prerequisites for a given course code (recursively)""" 

    if checked_courses is None: 
        checked_courses = set()

    if code in checked_courses:
        return []

    checked_courses.add(code)

    course = courses_by_number.get(code)
    if not course:
        return []
    
    all_prereqs = []

    for prereq_code in course.prerequisites:
        all_prereqs.append(prereq_code)

        nested_prereqs = get_all_prereqs(prereq_code, courses_by_number, checked_courses)
        all_prereqs.extend(nested_prereqs)

    return all_prereqs    



